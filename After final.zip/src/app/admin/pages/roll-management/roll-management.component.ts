import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roll-management',
  templateUrl: './roll-management.component.html',
  styleUrls: ['./roll-management.component.css']
})
export class RollManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
