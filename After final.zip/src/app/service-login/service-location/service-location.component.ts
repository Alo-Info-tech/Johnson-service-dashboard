import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-location',
  templateUrl: './service-location.component.html',
  styleUrls: ['./service-location.component.css']
})
export class ServiceLocationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
