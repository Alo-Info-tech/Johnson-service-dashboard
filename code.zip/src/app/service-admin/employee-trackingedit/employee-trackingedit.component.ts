import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-trackingedit',
  templateUrl: './employee-trackingedit.component.html',
  styleUrls: ['./employee-trackingedit.component.css']
})
export class EmployeeTrackingeditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
