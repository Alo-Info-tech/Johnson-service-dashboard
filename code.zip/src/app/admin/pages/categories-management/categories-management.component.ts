import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categories-management',
  templateUrl: './categories-management.component.html',
  styleUrls: ['./categories-management.component.css']
})
export class CategoriesManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
