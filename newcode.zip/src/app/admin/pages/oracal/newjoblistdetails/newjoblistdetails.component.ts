import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newjoblistdetails',
  templateUrl: './newjoblistdetails.component.html',
  styleUrls: ['./newjoblistdetails.component.css']
})
export class NewjoblistdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
