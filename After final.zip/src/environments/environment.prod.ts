export const environment = {
  production: true,

  //Dev URL///

  apiUrl: 'http://smart.johnsonliftsltd.com:3000/api/',
  imageURL: 'http://smart.johnsonliftsltd.com:3000/upload'




   //Live URL//

  //  apiUrl: 'http://52.25.163.13:3000/api/',

  //  imageURL: 'http://52.25.163.13:3000/api/'







  // apiUrl: 'http://localhost:91/'
};

