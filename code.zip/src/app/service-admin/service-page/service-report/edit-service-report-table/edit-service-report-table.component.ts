import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-service-report-table',
  templateUrl: './edit-service-report-table.component.html',
  styleUrls: ['./edit-service-report-table.component.css']
})
export class EditServiceReportTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
