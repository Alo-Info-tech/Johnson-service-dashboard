import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-admin',
  templateUrl: './service-admin.component.html',
  styleUrls: ['./service-admin.component.css']
})
export class ServiceAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
