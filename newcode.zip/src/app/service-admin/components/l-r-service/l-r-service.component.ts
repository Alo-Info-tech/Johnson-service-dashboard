import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-l-r-service',
  templateUrl: './l-r-service.component.html',
  styleUrls: ['./l-r-service.component.css']
})
export class LRServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
