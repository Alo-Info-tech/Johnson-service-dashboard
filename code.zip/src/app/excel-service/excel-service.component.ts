import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-excel-service',
  templateUrl: './excel-service.component.html',
  styleUrls: ['./excel-service.component.css']
})
export class ExcelServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
