import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-breakdownpdf',
  templateUrl: './breakdownpdf.component.html',
  styleUrls: ['./breakdownpdf.component.css']
})
export class BreakdownpdfComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
