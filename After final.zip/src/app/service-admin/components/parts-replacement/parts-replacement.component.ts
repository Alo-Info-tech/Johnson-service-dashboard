import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parts-replacement',
  templateUrl: './parts-replacement.component.html',
  styleUrls: ['./parts-replacement.component.css']
})
export class PartsReplacementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
